import operator

print("### Operator Hitung ###")
print("=== Penjumlahan ===")
operator.tambah(2, 5)

print()
print("=== Pengurangan ===")
operator.kurang(8, 3)

print()
print("=== Perkalian ===")
operator.kali(5, 5)

print()
print("=== Pembagian ===")
operator.bagi(12, 3)

print()
print("=== Pemangkatan ===")
operator.pangkat(5, 2)


print()
import bangundatar
print('=== Perhitungan Luas Bangun Datar ===')
bangundatar.l_persegi(8)

print()
bangundatar.l_persegipanjang(2,5)

print()
bangundatar.l_lingkaran(7)

print()
bangundatar.l_segitiga(2, 12)

print()
bangundatar.l_jajargenjang(4, 6)

print()
print('=== Perhitungan Luas Bangun Ruang ===')
import bangunruang
bangunruang.luas_kubus(9)

print()
bangunruang.luas_balok(2, 6, 12)

print()
bangunruang.luas_tabung(14, 25)

print()
bangunruang.lp_limas(6, 5, 6)

print()
bangunruang.lp_prisma_segitiga(5, 12, 20, 13)
