import math

def luas_kubus(sisi):
    luas = 6 * sisi * sisi
    print(f'luas kubus adalah 6 * {sisi} *{sisi} = {luas}')

def luas_balok(panjang, lebar, tinggi):
    luas = 2 * (panjang * lebar + lebar * tinggi + panjang * tinggi)
    print(f'luas balok adalah 2 * {(panjang * lebar + lebar * tinggi + panjang * tinggi)} = {luas}')

def luas_tabung(jari, tinggi):
    luas = 2 * 22/7 * jari * (jari + tinggi)
    print(f'luas tabung adalah 2 * 22/7 * {jari} * {(jari + tinggi)} = {luas}')

def lp_limas(alas, tinggi, sisi):
    lp = (4 * 1/2 * alas * tinggi) + (sisi * sisi)
    print(f'luas permukaan limas adalah {(4 * 1/2 * alas * tinggi)} + {(sisi * sisi)} = {lp}')

def lp_prisma_segitiga(alas, t, tinggi, c):
    #rumus: 2 * luas alas + keliling alas * tinggi 
    lp = 2 * (1/2 * alas * t) + (alas + t + c) * tinggi
    print(f'luas permukaan prisma adalah 2 * {(1/2 * alas * t)} + {(alas + t + c)} * {tinggi} = {lp}')